var helperFunctions = { 
    buildResponse: function(options) {
        var response = {
            version: "1.0",
            response: {
                outputSpeech: {
                type: "SSML",
                ssml: "<speak>" + options.speechText + "</speak>" 
                },
                shouldEndSession: options.endSession
            }
        };

        if(options.repromptText){
            response.response.repromptText = {
                outputSpeech: {
                    type: "SSML",
                    ssml: "<speak>" + options.repromptText + "</speak>" 
                }
            }
        };

        if(options.session && options.session.attributes) {
            response.sessionAttributes = options.session.attributes;
        }

        if(options.cardTitle) {
            response.response.card = {
                type: "Simple",
                title: options.cardTitle,
                content: "Welcome to Leeds Football Skill"
            }
        }

        if(options.imageUrl){
            response.response.card.type = "Standard";
            response.response.card.text = options.cardContent;
            response.response.card.image = {
                smallImageUrl: options.imageUrl,
                largeImageUrl: options.imageUrl
            };
        } else {
            
            // response.response.card.content = options.cardContent;
        }

        return response;
    }
}

module.exports = helperFunctions;